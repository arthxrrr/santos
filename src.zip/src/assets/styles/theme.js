// src/assets/styles/theme.js
export const colors = {
    primary: '#3498db',
    secondary: '#2c3e50',
    danger: '#e74c3c',
    light: '#ecf0f1',
    dark: '#2c3e50',
    background: '#f5f5f5'
  };